/** @jsx jsx */
import React from "react";
import { jsx } from "@emotion/core";
import Section from "../Section";
import ExperienceItem from "./ExperienceItem";
import Divider from "../Divider";

function Experience() {
  return (
    <Section title="Experience">
      <ExperienceItem
        role="Associate Senior Software Engineer"
        length="09/2017 to Present"
        company="Cerner"
        location="Kansas City, MO"
        description="Wrote, enhanced, and deployed new and legacy solutions in the population health space following both technical and functional specifications. Identify process improvements at the team level to support the operations and development ecosystem. Collaborate on component level technical designs as well as provide mentoring for teammates and assist others in debugging and documenting root cause analysis and resolution."
      >
        <React.Fragment>
          <li>
            <strong>Collaborate</strong> on a Web Application SDK for hundreds
            of web applications to consume which absorbs the complexity of
            application development. We focus on development agility and
            providing an excellent developer experience through elegant CLI
            scripts, enforcing standards, and encapsulating common configuration
            (e.g. webpack config, authorization & authentication workflows, and
            middleware).
          </li>
          <li>
            <strong>Create</strong> a framework for easing the development of
            microfrontends for first-party patient facing applications by
            abstracting away and encapsulating complex configuration and typical
            defaults.
          </li>
          <li>
            <strong>Partner</strong> with a User Experience team to implement
            consistent, design-system compliant React components for reuse
            across multiple organizations spanning thousands of consumers.
          </li>
          <li>
            <strong>Develop and maintain</strong> many patient-facing
            applications powered by multiple Ruby on Rails microservices and
            React view layers.
          </li>
        </React.Fragment>
      </ExperienceItem>
      <Divider inner />
      <ExperienceItem
        role="Embedded Systems Engineer / Mobile Developer"
        length="12/2016 to 09/2017"
        company={
          <span>
            Intellifarms (<em>now AGI Suretrack</em>)
          </span>
        }
        location="Archie, MO"
        description="Utilize knowledge of digital circuits, analog filters and amplifiers, and low power switching power supplies to design custom circuitry and ASICs. Provide direct value to farmers through proficiency in C, communication protocols, and system design by developing the firmware and userspace applications for the aforementioned hardware while keeping real-time performance in mind."
        extraHeaderInfo={
          <p>
            <strong>Engineering Intern</strong>
            <div>05/2015 to 11/2016</div>
          </p>
        }
      >
        <React.Fragment>
          <li>
            <strong>Delivered</strong> high-performance real-time embedded
            firmware for custom-built ASICs.
          </li>
          <li>
            <strong>Designed and produced</strong> modular, custom circuitry for
            Bluetooth and low-power switching supplies.
          </li>
          <li>
            <strong>Developed and published</strong> native iOS and Android
            applications that communicated by custom protocols over Bluetooth
            Low Energy with various Intellifarms products, like BinManager,
            Field Data Manager, and BinCheck.
          </li>
        </React.Fragment>
      </ExperienceItem>
    </Section>
  );
}

export default Experience;
