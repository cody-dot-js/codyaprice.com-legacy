/** @jsx jsx */
import { jsx, css } from "@emotion/core";
import spacing from "../spacing";
import SectionHeader from "../SectionHeader";

function ExperienceItem({
  role,
  length,
  company,
  location,
  description,
  extraHeaderInfo,
  children
}) {
  return (
    <div
      css={css`
        :not(:last-of-type) {
          margin-bottom: ${spacing.medium};
        }
      `}
    >
      <SectionHeader
        start={
          <div>
            <strong>{role}</strong>
            <div>{length}</div>
          </div>
        }
        middle={company}
        end={location}
      />
      {extraHeaderInfo}
      <p>{description}</p>
      <ul
        css={css`
          list-style: disc;
          padding-left: 1rem;
        `}
      >
        {children}
      </ul>
    </div>
  );
}

export default ExperienceItem;
