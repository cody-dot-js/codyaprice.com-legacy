/** @jsx jsx */
import { jsx, css } from "@emotion/core";

function Section({ title, children }) {
  return (
    <section
      css={css`
        margin-bottom: 1.5rem;
      `}
    >
      <h2
        css={css`
          text-align: center;
        `}
      >
        {title}
      </h2>
      {children}
    </section>
  );
}

export default Section;
