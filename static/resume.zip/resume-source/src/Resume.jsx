/** @jsx jsx */
import { jsx, css } from "@emotion/core";
import Header from "./header";
import ProfileStatement from "./ProfileStatement";
import DevelopmentMethodsToolsAndTechnologies from "./development-methods-tools-and-tech";
import Experience from "./experience";
import Education from "./Education";
import spacing from "./spacing";
import Divider from "./Divider";

function Resume() {
  return (
    <div>
      <Header />
      <main
        css={css`
          margin: ${spacing.medium};
        `}
      >
        <ProfileStatement />
        <Divider />
        <DevelopmentMethodsToolsAndTechnologies />
        <Divider />
        <Experience />
        <Divider />
        <Education />
      </main>
    </div>
  );
}

export default Resume;
