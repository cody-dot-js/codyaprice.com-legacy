/** @jsx jsx */
import React from "react";
import { jsx, css } from "@emotion/core";
import Section from "./Section";
import SectionHeader from "./SectionHeader";

function Education() {
  return (
    <Section title="Education">
      <SectionHeader
        start={
          <React.Fragment>
            <strong>
              Dual Bachelor of Science: Electrical and Computer Engineering
            </strong>
            &nbsp;(<em>with honors</em>)
          </React.Fragment>
        }
        middle="University of Missouri-Columbia"
        end="Columbia, MO"
      />
      <ul
        css={css`
          list-style: inside;
        `}
      >
        <li>
          <strong>Minor:</strong>&nbsp;Computer Science
        </li>
        <li>
          <strong>Emphasis:</strong>&nbsp;Digital and Wireless Communication
        </li>
      </ul>
    </Section>
  );
}

export default Education;
