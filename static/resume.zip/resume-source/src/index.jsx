import React from "react";
import ReactDOM from "react-dom";
import Resume from "./Resume";
import ResetCss from "./ResetCss";
import GlobalCss from "./GlobalCss";

const RenderedResume = () => (
  <>
    <ResetCss />
    <GlobalCss />
    <Resume />
  </>
);

ReactDOM.render(<RenderedResume />, document.body);
