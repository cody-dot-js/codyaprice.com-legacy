/** @jsx jsx */
import { jsx, css } from "@emotion/core";
import Section from "./Section";
import spacing from "./spacing";

function ProfileStatement() {
  return (
    <Section title="Profile Statement">
      <p>
        <strong>Software engineer</strong> with experience and comfort at all
        levels of the stack, but with a passion for performance and creating a
        delightful user experience. Loves to collaborate with others to bring
        innovative and performant software solutions that meet business demands
        for excellence, agility, and flexibility.
      </p>
      <ul
        css={css`
          list-style: disc;
          padding-left: ${spacing.medium};
        `}
      >
        <li>
          <em>
            "Cody is awesome. Being a quick learner is one of his key
            attributes.
            <strong>I feel like I could throw anything at him.</strong> He was
            on a team of handpicked associates to knock out requests for an
            extremely high priority partnership that got focus from the highest
            levels of Cerner. Also, with little notice (1-2 days), Cody learned
            and helped develop a prototype for American Well video visits to
            show that we could integrate it into our platform. This effort
            impressed Strategic Growth executives to the point where they wanted
            Cody to lead the development of the application."
          </em>
          &nbsp;— 2019 Annual Review
        </li>
        <li>
          <em>
            "Proven to be exceptionally agile at picking up our team's
            technology stack and quickly becoming a{" "}
            <strong>technical leader</strong> in the space...In addition to his
            quick technical prowess, Cody proved to be able to understand the
            technical cost of client requests and to help weigh the cost-benefit
            of implementing them."
          </em>
          &nbsp;— 2018 Annual Review
        </li>
      </ul>
    </Section>
  );
}

export default ProfileStatement;
