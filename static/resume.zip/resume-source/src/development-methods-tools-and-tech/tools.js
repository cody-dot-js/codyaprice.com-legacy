const tools = [
  "Accessibility (Section 508 & WCAGAA)",
  "C",
  "C++",
  "CORS",
  "CSS3",
  "Git",
  "HTML5",
  "Java",
  "JavaScript",
  "Native Mobile Development (iOS, Android)",
  "Node.js",
  "Rails",
  "ReactJS",
  "Ruby",
  "Swift",
  "Webpack"
];

export default tools;
