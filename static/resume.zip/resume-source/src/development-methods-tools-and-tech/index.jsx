/** @jsx jsx */
import { jsx, css } from "@emotion/core";
import Section from "../Section";
import methods from "./methods";
import tools from "./tools";
import spacing from "../spacing";

function DevelopmentMethodsToolsAndTechnologies() {
  return (
    <Section title="Development Methods, Tools, and Technologies">
      <h6
        css={css`
          margin-bottom: ${spacing.small};
        `}
      >
        Methods
      </h6>
      <p>{methods.join(", ")}</p>
      <h6
        css={css`
          margin-bottom: ${spacing.small};
        `}
      >
        Tools and Technologies
      </h6>
      <p>{tools.join(", ")}</p>
    </Section>
  );
}

export default DevelopmentMethodsToolsAndTechnologies;
