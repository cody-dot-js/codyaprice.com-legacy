const methods = [
  "Agile Development",
  "Authentication and Authorization Workflows",
  "Developer Experience-Driven Infrastructure",
  "Microfrontend Architecture",
  "Microservice Architecture",
  "Minimalism",
  "Mobile-First Design",
  "Pragmatism",
  "Single Page Application Development",
  "Test Driven Development (TDD)"
];

export default methods;
