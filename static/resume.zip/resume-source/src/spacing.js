const spacing = {
  xsmall: "0.25rem",
  small: "0.5rem",
  medium: "1rem",
  large: "1.5rem",
  xlarge: "2rem"
};

export default spacing;
