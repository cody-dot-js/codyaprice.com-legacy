/** @jsx jsx */
import { css, jsx } from "@emotion/core";
import spacing from "./spacing";

function SectionHeader({ start, middle, end }) {
  return (
    <ul
      css={css`
        display: grid;
        grid-template-columns: 1fr 1fr 1fr;
        margin-bottom: ${spacing.small};
      `}
    >
      <li>{start}</li>
      <li
        css={css`
          text-align: center;
        `}
      >
        {middle}
      </li>
      <li
        css={css`
          text-align: end;
        `}
      >
        {end}
      </li>
    </ul>
  );
}

export default SectionHeader;
