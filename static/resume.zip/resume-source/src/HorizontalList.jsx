/** @jsx jsx */
import React from "react";
import { jsx, css } from "@emotion/core";
import spacing from "./spacing";

function Divider() {
  return (
    <li
      css={css`
        color: rgba(0, 0, 0, 0.38);
      `}
    >
      |
    </li>
  );
}

function HorizontalList({ children }) {
  const listItems = React.Children.toArray(children).reduce(
    (acc, item, i, original) => {
      return i === original.length - 1
        ? acc.concat(item)
        : acc.concat(item, <Divider />);
    },
    []
  );

  return (
    <ul
      css={css`
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: ${spacing.small};
      `}
    >
      {listItems}
    </ul>
  );
}

export default HorizontalList;
