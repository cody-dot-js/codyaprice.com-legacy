/** @jsx jsx */
import { jsx, css, Global } from "@emotion/core";
import spacing from "./spacing";

function GlobalCss() {
  return (
    <Global
      styles={css`
        html {
          box-sizing: border-box;
          font-family: Roboto, "Helvetica Neue", Helvetica, Arial, sans-serif;
          font-size: 100%; /* set base font size to 16px */
          color: rgba(0, 0, 0, 0.87);
        }

        body {
          line-height: 1.125rem;

          // @media print {
          //   color: #000;
          // }
        }

        h1,
        h2,
        h3,
        h4,
        h5,
        h6 {
          font-weight: 700;
          margin-bottom: ${spacing.large};
        }

        h1 {
          font-size: ${spacing.xlarge};
        }

        h2 {
          font-size: ${spacing.large};
        }

        h3 {
          font-size: 1.25rem;
        }

        h4 {
          font-size: ${spacing.medium};
        }

        h5 {
          font-size: 0.875rem;
        }

        h6 {
          font-size: 0.75rem;
        }

        p {
          line-height: ${spacing.large};
          margin-bottom: ${spacing.medium};
        }

        strong {
          font-weight: 700;
        }

        em {
          font-style: italic;
        }

        li {
          margin-bottom: ${spacing.xsmall};
        }

        *,
        *::before,
        *::after {
          box-sizing: inherit;
        }
      `}
    />
  );
}

export default GlobalCss;
