/** @jsx jsx */
import { css, jsx } from "@emotion/core";
import PropTypes from "prop-types";

const propTypes = {
  inner: PropTypes.bool
};

const defaultProps = {
  inner: false
};

function Divider({ inner }) {
  const style = inner
    ? css`
        height: 0;
        border-top: 1px dashed rgba(0, 0, 0, 0.1);
        border-bottom: 1px dashed rgba(255, 255, 255, 0.3);
      `
    : css`
        background-image: linear-gradient(
          to right,
          rgba(0, 0, 0, 0),
          rgba(0, 0, 0, 0.38),
          rgba(0, 0, 0, 0)
        );
      `;
  return (
    <hr
      css={css`
        border: 0;
        height: 1px;
        margin-bottom: 1rem;
        ${style}
      `}
    />
  );
}

Divider.propTypes = propTypes;
Divider.defaultProps = defaultProps;

export default Divider;
