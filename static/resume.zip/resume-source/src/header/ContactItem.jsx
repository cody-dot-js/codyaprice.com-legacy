/** @jsx jsx */
import { jsx, css } from "@emotion/core";
import spacing from "../spacing";

function ContactItem({ title, children, ...otherProps }) {
  return (
    <li
      css={css`
        display: grid;
        grid-template-columns: 1fr 1fr;
        grid-gap: ${spacing.medium};
        :not(:last-of-type) {
          margin-bottom: ${spacing.medium};
        }
      `}
      {...otherProps}
    >
      <strong
        css={css`
          display: flex;
          flex-direction: row-reverse;
        `}
      >
        {title}:
      </strong>
      {children}
    </li>
  );
}

export default ContactItem;
