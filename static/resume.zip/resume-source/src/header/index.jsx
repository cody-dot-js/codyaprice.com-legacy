/** @jsx jsx */
import { jsx, css } from "@emotion/core";
import ContactItem from "./ContactItem";
import spacing from "../spacing";

const contactInfo = [
  { title: "Email", display: "dev.cprice@gmail.com" },
  { title: "Phone", display: "816.617.1248" },
  {
    title: "Address",
    display: (
      <span>
        5603 E. 101st St.,
        <div>Kansas City, MO 64137</div>
      </span>
    )
  },
  {
    title: "Website",
    display: (
      <a
        href="https://codyaprice.com"
        css={css`
          color: #fff;

          // @media print {
          //   color: #000;
          // }
        `}
      >
        codyaprice.com
      </a>
    )
  },
  {
    title: "Download resume source",
    display: (
      <a
        href="https://codyaprice.com/resume"
        css={css`
          color: #fff;
        `}
      >
        codyaprice.com/resume
      </a>
    )
  }
];

function Header() {
  return (
    <header
      css={css`
        align-items: center;
        background-color: #303030;
        border-bottom-left-radius: ${spacing.xsmall};
        border-bottom-right-radius: ${spacing.xsmall};
        box-shadow: rgba(0, 0, 0, 0.38) 0 ${spacing.xsmall} ${spacing.small} 0;
        color: #fff;
        display: flex;
        justify-content: space-between;
        margin-bottom: ${spacing.medium};
        padding: ${spacing.medium};

        // @media print {
        //   color: #000;
        //   background-color: #f0f0f0;
        // }
      `}
    >
      <div>
        <h1>Cody A. Price</h1>
        <h2>Software Engineer</h2>
      </div>
      <ul
        css={css`
          list-style: none;
          margin: 0;
        `}
      >
        {contactInfo.map(({ title, display }) => (
          <ContactItem key={title} title={title}>
            {display}
          </ContactItem>
        ))}
      </ul>
    </header>
  );
}

export default Header;
