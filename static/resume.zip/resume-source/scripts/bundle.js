const { execSync } = require("child_process");
const fs = require("fs-extra");

// remove any old resume if it exists
if (fs.existsSync("resume.zip")) {
  fs.unlinkSync("resume.zip");
}

// remove stale things (maybe) and create a new temp directory
fs.rmdirSync("resume-source", { recursive: true });
fs.mkdirSync("resume-source");

// copy all the assets that matter:
// - package.json
// - src directory
// - public directory
// - scripts directory
fs.copySync("package.json", "resume-source/package.json");
fs.copySync("src", "resume-source/src");
fs.copySync("public", "resume-source/public");
fs.copySync("scripts", "resume-source/scripts");

// delegate to mac os zip command, zip up resume dir into resume.zip
execSync("zip -vr resume.zip resume-source/");

// cleanup after yourself, Cody
fs.rmdirSync("resume-source", { recursive: true });
